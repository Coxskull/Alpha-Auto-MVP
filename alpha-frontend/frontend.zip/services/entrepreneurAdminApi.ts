import api from "./api";

import type { EntrepreneurProgram } from "../types/entrepreneur";

/**
 * Get Entrepreneur Network configuration
 */
export async function getEntrepreneurConfiguration(): Promise<EntrepreneurProgram> {
  const response = await api.get<EntrepreneurProgram>(
    "/api/admin/entrepreneur/configuration"
  );

  return response.data;
}

/**
 * Update Entrepreneur Network configuration
 */
export async function updateEntrepreneurConfiguration(
  configuration: EntrepreneurProgram
): Promise<EntrepreneurProgram> {
  const response = await api.put<EntrepreneurProgram>(
    "/api/admin/entrepreneur/configuration",
    configuration
  );

  return response.data;
}