import api from "@/services/api";
import type { ServiceRequest } from "@/types/serviceRequest";

export type ServiceRequestPayload = {
  customerId?: string;
  customerName: string;
  customerPhone?: string;
  vehicleInfo?: string;
  issueDescription: string;
  serviceAddress: string;
  zone: string;
  finalAmount: number;
};

export async function createServiceRequest(data: ServiceRequestPayload) {
  const response = await api.post<ServiceRequest>("/api/ServiceRequests", data);
  return response.data;
}

export async function getServiceRequests() {
  const response = await api.get<ServiceRequest[]>("/api/ServiceRequests");
  return response.data;
}

export async function getServiceRequest(id: string) {
  const response = await api.get<ServiceRequest>(`/api/ServiceRequests/${id}`);
  return response.data;
}

export async function assignProvider(id: string) {
  const response = await api.post(`/api/ServiceRequests/${id}/assign-provider`);
  return response.data;
}

export async function assignMechanic(id: string) {
  const response = await api.post(
    `/api/ServiceRequests/${id}/assign-nearest-mechanic`
  );
  return response.data;
}

export async function assignDriver(id: string) {
  const response = await api.post(`/api/ServiceRequests/${id}/assign-driver`);
  return response.data;
}

export async function requestParts(
  id: string,
  partDescription: string,
  notes?: string
) {
  const response = await api.post(`/api/ServiceRequests/${id}/request-parts`, {
    partDescription,
    notes,
  });

  return response.data;
}